<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml"
   xmlns:wfs="http://www.opengis.net/wfs"
   xmlns:ogc="http://www.opengis.net/ogc"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://services.kystverket.no/wfs.ashx?SERVICE=WFS&amp;VERSION=1.1.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=layer_552&amp;OUTPUTFORMAT=text/xml;%20subtype=gml/3.1.1  http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.1.0/wfs.xsd">
      <gml:boundedBy>
      	<gml:Envelope srsName="EPSG:4326">
      		<gml:lowerCorner>59.002776 10.398375</gml:lowerCorner>
      		<gml:upperCorner>59.904787 11.221622</gml:upperCorner>
      	</gml:Envelope>
      </gml:boundedBy>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.173">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.013595 10.560858</gml:lowerCorner>
        		<gml:upperCorner>59.904787 10.721424</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.904787 10.721424 59.901865 10.710999 59.900753 10.707973 59.893879 10.689278 59.890780 10.682542 59.875890 10.650206 59.819699 10.588001 59.806749 10.577328 59.767764 10.574016 59.763846 10.573684 59.749838 10.575517 59.728651 10.581637 59.720126 10.581784 59.710293 10.593389 59.691462 10.600343 59.687395 10.603836 59.685387 10.605559 59.680309 10.610336 59.679007 10.612239 59.678602 10.612333 59.658844 10.616875 59.648254 10.623394 59.630064 10.630968 59.610807 10.635662 59.604456 10.636487 59.593558 10.638175 59.579751 10.639966 59.569794 10.640578 59.567711 10.640706 59.542850 10.618799 59.521784 10.597579 59.515435 10.591189 59.512851 10.588590 59.487071 10.580781 59.483712 10.579538 59.451681 10.567704 59.435362 10.560858 59.412532 10.569707 59.401418 10.574010 59.377763 10.583893 59.346387 10.596640 59.314837 10.609431 59.295684 10.615623 59.267373 10.624762 59.219165 10.639682 59.207672 10.643232 59.178330 10.653186 59.160514 10.659501 59.155876 10.659808 59.139999 10.660858 59.114359 10.662551 59.013595 10.669173 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Færder - Oslo (dynaløpet)</ms:navn>
        <ms:farledtype>Hovedled</ms:farledtype>
        <ms:farlednummer>1000</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.180">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.295684 10.537542</gml:lowerCorner>
        		<gml:upperCorner>59.339464 10.615623</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.295684 10.615623 59.301578 10.604141 59.307289 10.594116 59.316696 10.577590 59.339464 10.537542 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Syd av Mefjordbåen - Slagentangen</ms:navn>
        <ms:farledtype>Hovedled</ms:farledtype>
        <ms:farlednummer>1007</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.191">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.194417 10.621153</gml:lowerCorner>
        		<gml:upperCorner>59.223741 10.739615</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.194417 10.739615 59.219165 10.639682 59.221364 10.630780 59.223741 10.621153 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Syd av Rauer</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2009</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.573">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.087339 10.970778</gml:lowerCorner>
        		<gml:upperCorner>59.134963 11.221622</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.087339 11.221622 59.087339 11.221620 59.091377 11.125062 59.110204 11.110209 59.122415 11.026617 59.123535 11.020078 59.126396 10.993020 59.134963 10.970778 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Bævøskjærsleia/Singlefjorden</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2002</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.574">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.075868 10.971017</gml:lowerCorner>
        		<gml:upperCorner>59.124472 11.011211</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.075868 10.971017 59.089810 10.988226 59.124472 11.011211 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Stamholmleia</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2003</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.575">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.112255 10.651582</gml:lowerCorner>
        		<gml:upperCorner>59.156198 10.952556</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.112255 10.651582 59.114359 10.662551 59.125371 10.720062 59.132424 10.779674 59.132426 10.779693 59.138449 10.829509 59.135754 10.901467 59.135719 10.903270 59.134046 10.906307 59.133339 10.907478 59.131608 10.917522 59.138153 10.939256 59.142155 10.941257 59.144022 10.942424 59.145392 10.943590 59.146701 10.944763 59.148948 10.947214 59.151676 10.949125 59.154887 10.951644 59.156198 10.952556 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Kjøkøsundsleia Til Flyndregr.</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2004</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.576">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.139427 10.646717</gml:lowerCorner>
        		<gml:upperCorner>59.165682 10.863153</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.165682 10.863153 59.147254 10.833895 59.144457 10.771850 59.144457 10.771848 59.143078 10.737659 59.139999 10.660858 59.139427 10.646717 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Vesterelva Til Fredrikstad</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2005</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.577">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.165682 10.863153</gml:lowerCorner>
        		<gml:upperCorner>59.210107 10.908084</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.165682 10.863153 59.179477 10.874020 59.186103 10.881566 59.190978 10.888389 59.197582 10.896582 59.198749 10.897414 59.200177 10.898216 59.202154 10.899137 59.206155 10.898656 59.208245 10.903132 59.210107 10.908084 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Vesterelva Til Fredrikstad</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2005</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.578">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.021877 10.772859</gml:lowerCorner>
        		<gml:upperCorner>59.142890 10.897248</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.021877 10.897248 59.040633 10.839460 59.044697 10.825054 59.072152 10.818965 59.132426 10.779693 59.142890 10.772859 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Søsterløpet/Rauer/Sletterrenna</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2010</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.579">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.142890 10.617453</gml:lowerCorner>
        		<gml:upperCorner>59.400252 10.772859</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.142890 10.772859 59.144457 10.771850 59.194417 10.739615 59.210988 10.728901 59.254710 10.710734 59.278716 10.694781 59.316979 10.669303 59.330957 10.658531 59.342013 10.653391 59.369389 10.636201 59.400252 10.617453 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Søsterløpet/Rauer/Sletterrenna</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2010</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.590">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.013595 10.669173</gml:lowerCorner>
        		<gml:upperCorner>59.159963 10.972514</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.159963 10.956545 59.149067 10.962751 59.134963 10.970778 59.125378 10.970667 59.123643 10.970647 59.116468 10.966304 59.111181 10.967063 59.106905 10.970892 59.104342 10.971041 59.088710 10.971948 59.081866 10.972514 59.075868 10.971017 59.067077 10.965664 59.047924 10.969767 59.035088 10.970862 59.024965 10.965578 59.021877 10.897248 59.018156 10.793933 59.017272 10.769702 59.013595 10.669173 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Via Løperen til Fredrikstad</ms:navn>
        <ms:farledtype>Hovedled</ms:farledtype>
        <ms:farlednummer>1002</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.591">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.159963 10.945123</gml:lowerCorner>
        		<gml:upperCorner>59.210343 10.959723</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.210343 10.959723 59.203210 10.949175 59.198490 10.945123 59.197274 10.945370 59.182889 10.951557 59.180990 10.952373 59.162653 10.956011 59.159963 10.956545 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Via Løperen Til Fredrikstad</ms:navn>
        <ms:farledtype>Hovedled</ms:farledtype>
        <ms:farlednummer>1002</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.593">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.210343 10.959723</gml:lowerCorner>
        		<gml:upperCorner>59.270730 11.095804</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.210343 10.959723 59.210963 10.961003 59.212413 10.962470 59.213629 10.963520 59.215274 10.964703 59.219031 10.969659 59.222693 10.975857 59.225572 10.981196 59.228986 10.986364 59.233189 10.991217 59.235614 10.993941 59.238769 10.998139 59.241670 11.003370 59.244561 11.008269 59.248828 11.013343 59.252943 11.017209 59.256910 11.019978 59.259568 11.022901 59.260332 11.025488 59.260970 11.029539 59.261411 11.036512 59.262304 11.043321 59.264301 11.050784 59.265590 11.055652 59.266528 11.058332 59.266579 11.061894 59.266392 11.068941 59.266420 11.075517 59.267109 11.083244 59.268220 11.087911 59.269495 11.090442 59.270730 11.091638 59.270546 11.095005 59.270381 11.095804 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Fredrikstad - Sarpsborg</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2015</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.608">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.013595 10.548582</gml:lowerCorner>
        		<gml:upperCorner>59.890780 10.682542</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.890780 10.682542 59.877180 10.644512 59.853961 10.606278 59.842274 10.582901 59.827856 10.576681 59.808841 10.564649 59.771310 10.559485 59.769629 10.559254 59.763218 10.556989 59.733693 10.556437 59.720754 10.570628 59.698307 10.586548 59.686594 10.602139 59.686373 10.602428 59.680309 10.610336 59.678602 10.612333 59.658844 10.616875 59.647961 10.612062 59.584814 10.626471 59.570238 10.629706 59.567919 10.629471 59.561952 10.623554 59.521084 10.583096 59.514208 10.576773 59.451723 10.554508 59.441150 10.550552 59.438549 10.549579 59.435884 10.548582 59.412585 10.557098 59.391432 10.564819 59.326506 10.587665 59.321699 10.589353 59.307289 10.594116 59.260788 10.609457 59.198915 10.629342 59.159541 10.643111 59.152519 10.644370 59.139427 10.646717 59.112255 10.651582 59.067778 10.659526 59.013595 10.669173 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Dyna - Hallangstangen</ms:navn>
        <ms:farledtype>Hovedled</ms:farledtype>
        <ms:farlednummer>1006</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.613">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.002776 10.398375</gml:lowerCorner>
        		<gml:upperCorner>59.155876 10.659808</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.002776 10.398375 59.019138 10.446192 59.059297 10.486762 59.066940 10.494495 59.079537 10.513532 59.085198 10.521415 59.102288 10.545233 59.142727 10.601709 59.143187 10.603710 59.152519 10.644370 59.155876 10.659808 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Laksskjær</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2035</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.614">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.112255 10.479702</gml:lowerCorner>
        		<gml:upperCorner>59.238780 10.651582</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.238780 10.479702 59.224402 10.481906 59.219938 10.486601 59.215977 10.493836 59.201716 10.519867 59.170052 10.561659 59.143187 10.603710 59.119283 10.641052 59.112255 10.651582 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Huikjæla</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2033</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.616">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.067778 10.455619</gml:lowerCorner>
        		<gml:upperCorner>59.151080 10.659526</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.151080 10.460056 59.137719 10.459559 59.133329 10.458894 59.111680 10.455619 59.089551 10.456679 59.089209 10.476486 59.088948 10.491508 59.085198 10.521415 59.067778 10.659526 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Færder – Hvasser – Mågerøflaket</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2038</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.620">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.104342 10.970647</gml:lowerCorner>
        		<gml:upperCorner>59.123643 10.976507</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.104342 10.971041 59.110878 10.975970 59.117484 10.976507 59.123643 10.970647 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Vest av Fugleskjærsgrunnen</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2007</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.621">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.149067 10.952556</gml:lowerCorner>
        		<gml:upperCorner>59.162653 10.962751</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.149067 10.962751 59.153051 10.956019 59.156198 10.952556 59.162653 10.956011 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Vest av Flyndregrunnen</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2008</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
    <gml:featureMember>
      <ms:layer_552 gml:id="layer_552.622">
        <gml:boundedBy>
        	<gml:Envelope srsName="EPSG:4326">
        		<gml:lowerCorner>59.278716 10.694781</gml:lowerCorner>
        		<gml:upperCorner>59.314282 10.776095</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:LineString srsName="EPSG:4326">
            <gml:posList srsDimension="2">59.278716 10.694781 59.294348 10.743957 59.306411 10.762829 59.314282 10.776095 </gml:posList>
          </gml:LineString>
        </ms:msGeometry>
        <ms:navn>Krokstadfjorden</ms:navn>
        <ms:farledtype>Biled</ms:farledtype>
        <ms:farlednummer>2020</ms:farlednummer>
      </ms:layer_552>
    </gml:featureMember>
</wfs:FeatureCollection>

