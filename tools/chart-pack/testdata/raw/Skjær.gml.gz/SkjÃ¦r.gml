<?xml version='1.0' encoding='UTF-8'?>
<wfs:FeatureCollection xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001 https://wfs.geonorge.no/skwms1/wfs.dybdedata?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;OUTPUTFORMAT=text%2Fxml%3B+subtype%3Dgml%2F3.2.1&amp;TYPENAME=app:Skj%C3%A6r&amp;NAMESPACES=xmlns(app,http%3A%2F%2Fskjema.geonorge.no%2FSOSI%2Fproduktspesifikasjon%2FDybdedata%2F20201001)" xmlns:wfs="http://www.opengis.net/wfs/2.0" timeStamp="2026-08-30T20:31:20Z" xmlns:gml="http://www.opengis.net/gml/3.2" numberMatched="unknown" numberReturned="0">
  <!--NOTE: numberReturned attribute should be 'unknown' as well, but this would not validate against the current version of the WFS 2.0 schema (change upcoming). See change request (CR 144): https://portal.opengeospatial.org/files?artifact_id=43925.-->
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.26807">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7d91b1de-2514-4756-b851-0b4f9935ffa8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:42</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.26807_APP_POSISJON'-->
        <gml:Point gml:id="skjer.26807_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.066006 10.998842</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.558">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>705abcd0-2543-4fe2-94d4-30636883f4e2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1998-11-25T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1998-11-25T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.558_APP_POSISJON'-->
        <gml:Point gml:id="skjer.558_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.293317 10.750119</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34050">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e1431ad3-7c1a-4c17-93e1-056be79385d3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34050_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34050_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.285504 10.737165</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35448">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>22b4e5cb-0405-4e8d-877e-44df841104b6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35448_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35448_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.271608 10.738072</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35449">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0a9ab409-fdf0-4c2e-8504-90ed4a9e137e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35449_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35449_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.263337 10.741471</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34170">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>cc08a99d-101b-423c-82a1-73b5d21bd22f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34170_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34170_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.174348 10.600036</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.108">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>dfbfd273-5ff4-4926-840c-0b3cbc6180b9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.108_APP_POSISJON'-->
        <gml:Point gml:id="skjer.108_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.057550 10.879381</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.109">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b6ce4228-314b-47c8-939c-f205c2ac11dc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.109_APP_POSISJON'-->
        <gml:Point gml:id="skjer.109_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.053281 10.887769</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.110">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e2496eab-883b-4b57-b810-f40731f667ed</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.110_APP_POSISJON'-->
        <gml:Point gml:id="skjer.110_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.053836 10.888703</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.111">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c4c75cc5-aa41-4198-943b-15de1018de32</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.111_APP_POSISJON'-->
        <gml:Point gml:id="skjer.111_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.062272 10.896911</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.112">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c644c948-f102-4e63-819d-abd8651f6543</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.112_APP_POSISJON'-->
        <gml:Point gml:id="skjer.112_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.057272 10.911253</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.113">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>463a4908-6a63-4ebe-916b-7681f58b07a7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.113_APP_POSISJON'-->
        <gml:Point gml:id="skjer.113_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.060294 10.902711</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.114">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c5240a02-70fd-4c1c-8773-023e659f405d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.114_APP_POSISJON'-->
        <gml:Point gml:id="skjer.114_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.058072 10.923681</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1164">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e722b325-0d58-41e9-b880-db96cd037eec</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1164_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1164_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.064114 10.917192</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1165">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4e48ef4a-1068-467d-b174-a80f70543bf8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1165_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1165_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.064392 10.920786</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1166">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e9233635-6a35-4302-99d3-8fc392f071ed</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1166_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1166_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.065919 10.928692</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1430">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fdb4ac15-64bf-4e74-8b7f-4d8c4c331844</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1430_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1430_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.063522 10.892036</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1432">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e0639251-d337-4cd1-8062-6675340aeb83</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1432_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1432_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.065242 10.890558</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1534">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>510f6943-bf1e-4c95-878e-84b606f284c7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1534_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1534_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.063800 10.901569</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1535">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>95049d9b-259b-40dd-800a-d2c5e04f8d4d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1535_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1535_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.063939 10.902314</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1537">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f7b643b4-1993-46c9-8cdc-33c86c273c1a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1537_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1537_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.064097 10.917175</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.26946">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fccf1f81-a9be-4e54-9438-2623a5f1d096</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:42</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.26946_APP_POSISJON'-->
        <gml:Point gml:id="skjer.26946_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.065850 10.879594</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.28043">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4b95ae5c-cb74-484a-b00d-b99db1d4c240</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:43</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.28043_APP_POSISJON'-->
        <gml:Point gml:id="skjer.28043_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.064028 10.917353</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54991">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>015f5fe1-aebe-4844-b35a-59b6ed242534</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54991_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54991_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.051314 10.962454</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54996">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8d1ce521-fa26-4a2a-951c-bdaffe30d6a7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54996_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54996_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059216 10.962488</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55163">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fc273e3f-360e-4b39-b006-d330ba1f198b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55163_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55163_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.064029 10.960436</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55165">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>58736bef-f04f-4329-aa93-69ab37d5bcc2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55165_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55165_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.058490 10.961469</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55169">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>eee6ad4d-d9b3-41f6-bed3-6c114266a243</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55169_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55169_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059647 10.956687</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55333">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>25288e9e-0cc1-4bf1-b0ca-8180c19031e9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55333_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55333_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.061982 10.960056</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55335">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3e42c819-e81b-4888-958a-3115c910c060</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55335_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55335_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.054340 10.961240</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.451">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b5f12d21-4a4e-4fde-a141-e8dff17eb2a2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.451_APP_POSISJON'-->
        <gml:Point gml:id="skjer.451_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059808 10.993706</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1167">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5b64f6bd-b5bb-4adb-8a5c-b1e30439d0c7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1167_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1167_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.066267 10.998969</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1168">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2135f716-5d67-4c12-8c99-72e9e7bbbeb6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1168_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1168_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.066022 10.998058</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1169">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1d6d96dc-ca08-40ec-bd1b-554948960373</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1169_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1169_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.069236 10.873736</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1170">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>846e60ef-874c-4049-890c-77cd07a182b2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1170_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1170_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.068836 10.885169</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1171">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>62b2057a-8404-472e-b0dd-874ae8de1fdc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1171_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1171_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.068992 10.886681</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1172">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>022fc964-24af-42bf-af9d-4820eb902e51</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1172_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1172_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.068975 10.886192</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1173">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0197fe27-bb95-4cc5-b17f-f8fd95850bec</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1173_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1173_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.068367 10.886583</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1174">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>99da2726-df97-4b71-b76f-8cce58a83d92</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1174_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1174_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.070972 10.979197</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1175">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8ae2225c-e4b9-40e8-90e0-c0bc0be267c7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1175_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1175_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.072794 10.981861</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1176">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>97cf58fb-8585-410e-8f68-2b2d2603f1bc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1176_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1176_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.072533 10.981761</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1177">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fca73c2a-c425-490d-9ba7-7637e7f28ceb</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1177_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1177_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.069253 10.987933</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1178">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>bcf7ec12-cc19-4196-8adc-d87afbbfcf0f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1178_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1178_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.069236 10.988206</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1179">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5603e624-1233-4382-baee-89095037bc02</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1179_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1179_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.067672 10.989000</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1431">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0b18b65f-c52a-4b07-99c6-6e8e183cab47</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1431_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1431_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.066369 10.889031</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1536">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5aa353aa-ab1c-43db-bcb1-4942d4daf0a4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1536_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1536_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.063836 10.917436</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.8810">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a1d99843-8281-4f9c-86a6-bf4c36c1f42c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-09-04T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-09-04T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:26</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.8810_APP_POSISJON'-->
        <gml:Point gml:id="skjer.8810_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.060339 10.917502</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.11651">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9d59ca57-bbf3-4f46-a172-b33fc3ec8e06</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-09-04T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-09-04T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:29</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.11651_APP_POSISJON'-->
        <gml:Point gml:id="skjer.11651_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.066746 10.927869</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20988">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5fee3fc8-e4e8-48bf-ab57-adc3cb721e16</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-09-04T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-09-04T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:37</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20988_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20988_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.067451 10.863673</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.26808">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>57d58d1c-8518-467d-83ba-6f5fa62c544e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:42</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.26808_APP_POSISJON'-->
        <gml:Point gml:id="skjer.26808_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.073003 10.981789</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.29501">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1bb6a93f-a3e0-48c2-b280-02b242445fa4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:44</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.29501_APP_POSISJON'-->
        <gml:Point gml:id="skjer.29501_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.056475 10.901536</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32415">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>73f45404-063e-446f-bdac-66cd0c95e02a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32415_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32415_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.103707 10.963787</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32416">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fed0977b-59cc-407e-ab66-2d0dd02dff8e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32416_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32416_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.101021 10.963217</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32417">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>cfb4a62f-c71f-4b20-a4f1-09dadcf3e868</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32417_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32417_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.096084 10.967867</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32430">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5a89e903-7ca0-4428-84a8-83133bea629a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32430_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32430_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.095223 10.950265</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32432">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>35f4389e-3da7-4864-bba9-3311dc37937d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32432_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32432_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.085540 10.941795</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32433">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3ddb8b4c-7f33-4739-833d-c0842dd791cd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32433_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32433_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.086028 10.943146</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32434">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c0586433-552c-4a8a-82a3-38019d6b32c3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32434_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32434_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.086387 10.943285</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32435">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3b644804-865a-46c0-a88c-816b0b4b26c6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32435_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32435_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.085791 10.943788</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32436">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>84523ffb-0081-46f9-adef-0bfe6311927a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32436_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32436_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.086064 10.944219</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32437">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8ec76d01-61fb-41f6-86ca-3b0ea38e3c8d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32437_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32437_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.079326 10.956854</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32438">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a3e14e16-6bfd-4f86-a2f5-40e57cc2da9e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32438_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32438_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.083772 10.957811</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33651">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>efeff98e-8e7f-4bcc-ac62-258bb31adcce</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33651_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33651_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.109132 10.965096</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33653">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a5bd397b-3cdf-43d9-9ae4-de8ac317fd33</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33653_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33653_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.106727 10.964918</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33655">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f7c2bc77-9e90-402e-993f-68abd1a0b859</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33655_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33655_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.106144 10.964699</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33684">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1566f935-7215-4927-a101-e22fab689587</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33684_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33684_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.076318 10.870747</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33685">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e7c03a00-0db1-44dd-b987-54fd11b47e3f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33685_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33685_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.076530 10.871021</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33686">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>63f11230-f9b8-470e-9a33-f0f3fd5d0163</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33686_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33686_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.074663 10.877326</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33687">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>908ab62c-98f3-4cfb-aeae-34b28e5898b8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33687_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33687_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.074965 10.877736</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33688">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>17675b0d-a3dc-49e1-9670-b5142d885e51</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33688_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33688_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.073585 10.888754</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35102">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>745e2321-23f5-4de6-8557-f23df9841445</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35102_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35102_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.091603 10.909700</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35103">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>aa93e333-4b1e-44d1-8d2c-0fbb8e46e3a5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35103_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35103_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.072201 10.839143</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35174">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>063da271-64b1-4142-a4ec-a9534b4e2bef</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35174_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35174_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.086120 10.961336</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35175">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>54931967-1b67-42bb-aaa2-cba4cbfcaeaa</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35175_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35175_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.088072 10.962606</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35176">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d2e10ae0-adab-4cbf-ac37-a85b72001ab2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35176_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35176_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.088380 10.960566</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35177">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>44e92a43-ee83-43a9-8b95-6d6d4aff20a9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35177_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35177_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.087812 10.961407</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35178">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1a1e6b45-b1d1-49bb-b6c7-68709c6735bf</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35178_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35178_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.089776 10.961260</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35180">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2840856b-4819-41cb-8a67-d25e4b63b943</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35180_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35180_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.072549 10.868492</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35181">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e5a43e14-4bc8-4856-bfa4-aaca5e738f29</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35181_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35181_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.074160 10.868056</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54501">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d7d6e7eb-830d-4d99-9be3-ee88fd1d7d7a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54501_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54501_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.050661 10.982840</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54502">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>71057eff-087f-4231-8e3e-284a6bc87da0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54502_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54502_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.060300 10.979482</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54503">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>90ef96c7-0060-4b5e-8b29-e9b559234862</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54503_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54503_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.050623 10.983025</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54504">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a7be9ae5-ccb8-40f4-960a-73baf31ecf4a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54504_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54504_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.062042 10.977747</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54505">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1949d93b-9fbe-4572-a03b-67fbbd0f4398</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54505_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54505_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.053203 10.983516</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54507">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>bb4e108a-b7d2-4fd4-9cb8-4afed34f1493</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54507_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54507_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.056669 10.991594</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54627">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>52ea9fca-f7d0-4b91-a643-8f61e779b00a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54627_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54627_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.063296 10.975731</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54628">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>36d5703d-05ce-472c-9c9c-043b56e9f9cc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54628_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54628_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.057950 10.979297</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54630">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8697b2b1-4948-4965-8e6e-3b240d2f5236</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54630_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54630_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.060934 10.988185</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54631">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>75b8f248-b7ae-4c49-8d46-9115e0bb34e2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54631_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54631_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.056599 10.991502</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54635">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e25f259b-cb49-414b-a036-6a2057cc1e8a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54635_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54635_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.058278 10.992596</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54636">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5393fd58-a680-498c-9402-8f128a6f9836</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54636_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54636_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.057326 10.990887</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54637">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e8dab1fc-405d-45b8-98d4-bb6878d97c33</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54637_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54637_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059744 10.985155</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54774">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1718cfd4-a70a-456b-b480-36a4bff2869c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54774_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54774_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.051069 10.983966</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54775">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2717e436-1bc0-48c4-9e53-4fd3b9360d20</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54775_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54775_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059079 10.980984</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54777">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8768f75e-6fc5-450e-aedb-da01c6016986</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54777_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54777_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.052871 10.992307</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54779">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>19f25a93-89de-4365-b25f-218e3cb1d455</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54779_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54779_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.057209 10.990953</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54780">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3083b9d7-6d6b-42e4-ae93-ee27df7aa198</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54780_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54780_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.050642 10.982892</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54781">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>08ce416c-d620-4200-b53d-7cead7d6aa1c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54781_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54781_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.050671 10.983416</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54782">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>edcaf7c1-5b08-41e3-bed4-55f48248c1e0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54782_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54782_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.061765 10.979966</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54784">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d800e919-31f7-4162-95ee-13cd5f35bbfa</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54784_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54784_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.054810 10.991451</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54894">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d8c38616-d803-4912-826d-1b6ea751a044</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54894_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54894_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059111 10.980210</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54897">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7e054819-a519-462d-b585-095ac7629c71</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54897_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54897_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059666 10.985109</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54898">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>04ea876c-b404-4f8e-b9c7-493ff03d27e2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54898_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54898_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059549 10.985159</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54900">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4c935ece-c378-47cc-b30b-fb97b2047859</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54900_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54900_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.057513 10.990030</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54901">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7ad9f0aa-acae-41fc-8738-5cef8588e023</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54901_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54901_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.060399 10.988162</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54902">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a7b9f453-c406-4c7c-9813-7664a52810a9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54902_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54902_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059413 10.985139</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54903">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8a856531-407a-452f-b424-32bcfc501417</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54903_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54903_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.061358 10.978780</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54987">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ec703fb7-ce02-4135-ae29-e6e03ec1b9fa</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54987_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54987_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059350 10.985327</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54988">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>00fd2019-624f-40a2-9725-c5a2120a5477</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54988_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54988_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.059454 10.981249</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54989">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4f48436a-0559-44c3-b7b4-d1c7ade29cd1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54989_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54989_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.055516 10.973615</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54990">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>40d04c3b-f346-4105-ac9e-b4fa60508d7a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54990_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54990_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.063417 10.977221</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54992">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a499f09b-09c4-4610-9990-f29aa949529d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54992_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54992_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.058718 10.959295</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54993">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d682e2bf-f200-4062-8209-4ad197cf1709</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54993_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54993_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.056442 10.959015</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54994">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>417f8d0c-142b-4e3d-b0e1-70229469e7c1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54994_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54994_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.062453 10.960682</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54995">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>78c92863-9d8e-4e9b-9f3a-e066df98cc89</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54995_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54995_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.052401 10.962313</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.54997">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>388d7239-a83d-4049-aec7-d7f16c747ddd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.54997_APP_POSISJON'-->
        <gml:Point gml:id="skjer.54997_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.061632 10.958625</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55164">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e050eb6c-eaf5-4371-8dbf-64461de2e5bd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55164_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55164_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.054114 10.961494</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55166">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>01caae90-a43e-4634-806d-51d23d91c30e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55166_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55166_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.054049 10.961547</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55168">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>90350730-50e5-438f-9189-4432c9d47a2b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55168_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55168_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.057082 10.958479</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55172">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>04bbc883-34e6-4722-9f03-e233ed857e2b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55172_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55172_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.058887 10.956504</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55334">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a2bac2cd-2535-4a50-85e6-0852da8b745a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55334_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55334_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.053898 10.961441</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55336">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6addc6e9-0e27-4192-8f6d-b177957e43e5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55336_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55336_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.052672 10.961940</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.55337">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7793193a-b586-47f6-9a31-1b300b5cf9c2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2017-09-21T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:03</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.55337_APP_POSISJON'-->
        <gml:Point gml:id="skjer.55337_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.061603 10.958221</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.390">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6542e694-9e47-4093-b831-5426531e76f4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1998-09-15T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1998-09-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.390_APP_POSISJON'-->
        <gml:Point gml:id="skjer.390_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.293489 10.665531</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.395">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3e583da0-9cc3-4770-bc6a-30abfc812f1f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1998-09-15T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1998-09-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.395_APP_POSISJON'-->
        <gml:Point gml:id="skjer.395_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.283942 10.676867</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.396">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>45a48975-3d28-4a1a-babf-6354556c8f85</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1998-09-15T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1998-09-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.396_APP_POSISJON'-->
        <gml:Point gml:id="skjer.396_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.286703 10.676833</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.50097">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fa90a05c-75e4-4960-9b63-9b00b163e668</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-06T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.50097_APP_POSISJON'-->
        <gml:Point gml:id="skjer.50097_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.278941 10.715025</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.56417">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fe701a19-ca53-40eb-b71e-bae6c42fadee</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-19T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:04</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.56417_APP_POSISJON'-->
        <gml:Point gml:id="skjer.56417_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.287063 10.678566</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.363">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c1fc0ad9-06be-4a9b-908d-a6ad36d380c7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1998-11-30T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1998-11-30T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:19</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.363_APP_POSISJON'-->
        <gml:Point gml:id="skjer.363_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117325 10.743989</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1180">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>94637f46-fcdb-4810-878c-b5c58a2fd85b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1180_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1180_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178644 10.859694</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.1181">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ee154722-0ac8-4fe1-90ac-4864321424ba</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:20</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.1181_APP_POSISJON'-->
        <gml:Point gml:id="skjer.1181_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178472 10.860419</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.18365">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8bdf9ee4-3dab-4fa3-a023-f27bd14464f7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-09-27T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-09-27T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:35</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.18365_APP_POSISJON'-->
        <gml:Point gml:id="skjer.18365_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.160517 10.835876</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.18366">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0c70ca04-ce52-474c-9cff-b0e0ca2c095d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-09-27T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-09-27T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:35</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.18366_APP_POSISJON'-->
        <gml:Point gml:id="skjer.18366_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.158688 10.837978</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.18367">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c5d8dc73-480d-4c0d-8ec9-0537ed7e2946</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-09-27T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-09-27T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:35</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.18367_APP_POSISJON'-->
        <gml:Point gml:id="skjer.18367_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.129914 10.853094</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.18368">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8a742ef3-09b9-4f03-b549-eda15cda0c78</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-09-27T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-09-27T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:35</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.18368_APP_POSISJON'-->
        <gml:Point gml:id="skjer.18368_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.123940 10.819982</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20144">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7554a8a4-b1f0-47dc-8867-0007f17b57f4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20144_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20144_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.169358 10.711322</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20145">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d786139d-54c4-465d-b02b-22192480d108</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20145_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20145_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170278 10.709869</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20146">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7dda0191-6ddb-4502-a5f3-20b5e075f5c8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20146_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20146_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.247831 10.693978</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20147">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3e2a1f8c-1145-4a3f-92d2-69c548d36abc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20147_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20147_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.183419 10.817625</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20148">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ca3ed3c5-f3db-4b66-97c6-8d497c5318b0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20148_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20148_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.211205 10.791677</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20149">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>91cb5bd3-8800-4b22-a1ba-173ad2ac4227</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20149_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20149_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.216879 10.785421</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20150">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5efb3925-4fe7-4a74-924c-52b43f60422c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20150_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20150_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.202624 10.792289</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20151">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2dff0c0a-9e75-4caf-8179-73346554fa8c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20151_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20151_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.175512 10.798882</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20152">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2cd39b1d-4841-4e79-9a44-3bb33894c01f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20152_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20152_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.231672 10.741812</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20153">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9d16224b-006b-4f7e-b5b8-0be18e5a9318</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20153_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20153_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.185930 10.803735</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20154">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>905336bb-1343-4441-bea5-5465315a0d90</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:36</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20154_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20154_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.180763 10.722688</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20989">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c7d501ce-0e65-4913-a4f8-1697a74e19b3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:37</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20989_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20989_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178289 10.712676</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.20990">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>95eb83ed-df32-416e-b1b9-77ce6072fe1c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:37</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.20990_APP_POSISJON'-->
        <gml:Point gml:id="skjer.20990_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172424 10.741876</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.26809">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9a25f3c9-cc9f-49db-8e44-21248da5c456</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>1999-01-12T23:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>1999-01-12T23:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:42</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.26809_APP_POSISJON'-->
        <gml:Point gml:id="skjer.26809_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178750 10.859847</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.28467">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>135125f8-49a0-434f-b704-565c619287af</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-09-27T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-09-27T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:44</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.28467_APP_POSISJON'-->
        <gml:Point gml:id="skjer.28467_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155348 10.820846</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.28961">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b71434ca-cbf9-473b-bc6d-3445a84b697f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:44</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.28961_APP_POSISJON'-->
        <gml:Point gml:id="skjer.28961_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172414 10.714236</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.28962">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1558b147-b17b-4663-8831-10d63c17bd73</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:førsteDatafangstdato>2000-10-09T22:00:00</app:førsteDatafangstdato>
      <app:oppdateringsdato>2000-10-09T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:44</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.28962_APP_POSISJON'-->
        <gml:Point gml:id="skjer.28962_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.205594 10.792835</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32792">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>08eb844a-4766-450d-b8d7-62876153c1fe</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32792_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32792_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170448 10.806656</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32793">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>33859736-c2ab-4d43-a3b2-db13513113be</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32793_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32793_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170798 10.806599</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32883">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>167391ea-9778-44ea-9778-f1964d26f1a5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32883_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32883_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170345 10.807963</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32884">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e2834134-fbc5-46e3-9791-16c040f6072f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32884_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32884_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170477 10.807254</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32885">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3e28fd3b-35aa-48ee-90c6-442f83faceaa</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32885_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32885_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170549 10.808289</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32886">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3ee564a7-6d34-41bf-b660-774a6b21dbf1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32886_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32886_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170849 10.808232</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32887">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3b87ff5f-6009-440a-b0df-b35304f96526</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32887_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32887_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.184734 10.818627</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33244">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>876a04ba-8291-4778-9c84-a0ff250d4dc1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33244_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33244_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.222444 10.742661</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33245">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7060cbae-31b5-441b-a2f3-94f57a908867</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33245_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33245_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.221432 10.745222</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33246">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8812b250-6890-4671-a5e4-463927da36e8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33246_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33246_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.217478 10.744452</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33247">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>783ead61-c9a0-4d4d-adf4-390e68b71186</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33247_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33247_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179859 10.802412</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33248">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ce36ec72-bf01-485d-aaa8-1d7d763cee81</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33248_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33248_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179908 10.802977</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33249">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4ede9906-0151-44d0-a3a9-927eacf0bb8e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33249_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33249_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179377 10.804048</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33250">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>414099b5-56d1-4c6f-a400-b5dc0e6e30ac</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33250_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33250_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179354 10.804630</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33251">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>63360dcd-9c8e-4381-b874-9d39caeb28d5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33251_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33251_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.181063 10.804589</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33252">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3cdc8d1f-37c0-4b9a-ab0c-a0202f9f4060</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33252_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33252_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168222 10.805186</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33330">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>149b61d1-89f6-493e-a4d6-164fb5c87005</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33330_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33330_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.171095 10.793331</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33331">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>58498b30-cb22-45cd-bb65-12771ca1eb97</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33331_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33331_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173251 10.800352</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33332">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e95620dc-2264-4ac1-97c5-ea04db4f242a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33332_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33332_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.174443 10.801342</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33333">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6e908a53-246a-4da6-a98e-3e156b78c5b3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33333_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33333_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.174695 10.799124</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33334">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>cf46e89e-a3dd-4ed2-b7e4-757d01476d00</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33334_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33334_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.174810 10.799518</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33449">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c1fca8b2-2f9f-4e05-9531-ac7701c6ac0b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33449_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33449_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.220241 10.741925</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33450">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2136b827-9242-4b32-845b-8e389139cb1d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33450_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33450_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.218554 10.742517</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33451">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8e92b738-c2a6-4a1c-85ec-ec1c5bd664b3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33451_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33451_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.221126 10.746921</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33561">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>48faffdd-05a5-478c-9c32-88ea9364c5ac</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33561_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33561_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.223483 10.744585</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33562">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b27012b0-58f9-4679-a96d-8f14751fefdc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33562_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33562_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.220779 10.745121</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33563">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a60ce519-4778-4a4d-ac36-32a030a503b2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33563_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33563_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.220479 10.745123</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33564">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>106927f4-e30c-4299-a8f6-9eb394e9e21c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33564_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33564_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.220592 10.745975</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33575">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>66ceefd2-c135-4873-8db9-43cfea5d2360</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33575_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33575_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.183081 10.802626</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33576">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e44a0fc6-aa92-49a4-9746-a7da9bf053fb</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33576_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33576_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.184362 10.804664</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33577">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>55f448d4-9ef1-4162-920e-0d5051baca4e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33577_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33577_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.184898 10.804372</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33578">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4875908c-80e3-4ae4-88b9-22202339a3fc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33578_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33578_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.185834 10.804611</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33579">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7b6ad882-a7b8-4df1-a46a-341099cd2a25</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33579_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33579_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.184915 10.808219</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33580">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b87f9add-2b27-4099-aea0-b358e84975fe</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33580_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33580_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.185258 10.808751</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33581">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2f33a076-738a-4d4b-978e-607de57f9ae3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33581_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33581_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.186366 10.809256</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33622">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>89483efd-527e-4baa-a218-9debf368c1b5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33622_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33622_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179269 10.807208</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33623">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3bf0b04c-a8e5-4999-ba68-8f2304f61ca2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33623_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33623_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178868 10.807631</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33624">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a50fa7a5-92ac-4a8a-a28a-2b7eaddbc74e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33624_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33624_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179053 10.812098</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33625">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>342cae24-3532-4dc5-8a13-2b3734e7dbb1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33625_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33625_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178203 10.814403</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33626">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b5c32bba-4924-4467-ac75-0adc25c0ffaf</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33626_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33626_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178004 10.814324</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33627">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4c682232-4386-4b25-b895-173d586f6af6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33627_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33627_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177909 10.813778</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33628">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f0ba8453-2f34-4f04-8bd6-ec26ccf5405c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33628_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33628_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177540 10.812836</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33629">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1fb6d2b5-d636-49c4-ab90-841bd0e5e4af</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33629_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33629_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177674 10.812391</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33630">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8ec96e97-b43d-4e1b-ad43-f9c4ca74336f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33630_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33630_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173528 10.815345</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33631">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>55558529-4ce0-4421-adfd-37a8ef9a7c9b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33631_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33631_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173228 10.815288</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33632">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>cd74c251-248c-4650-b444-3cfbbef02321</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33632_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33632_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173704 10.819651</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33633">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fc61f222-f8ff-41e2-bcf2-37ed228d2190</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33633_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33633_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.174405 10.819979</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33634">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>178b2bcb-392c-41d4-991c-4f746c3fe944</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33634_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33634_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.175014 10.819040</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33635">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>84193b43-3afe-4a37-9537-b27571db3207</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33635_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33635_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.175144 10.818455</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33636">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b50b8749-4815-41db-a225-201fadb0cfd8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33636_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33636_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.175430 10.815841</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33637">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7831d45f-600b-4aa1-9635-12333c3c68ab</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33637_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33637_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.169777 10.813065</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33638">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c67c0c06-b50b-4c0e-8c31-ee4e98ed1966</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33638_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33638_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.169551 10.815028</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33639">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a41ea1d0-b4cf-4828-be55-d538283b78db</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33639_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33639_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168602 10.814198</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33640">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ba83d230-11f6-4fbf-be72-db1eb6c7a052</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33640_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33640_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.169158 10.811961</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33641">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e8da5b7f-64cc-4794-af52-0ed96abd4ba7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33641_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33641_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.171455 10.826348</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33642">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3133fac1-c725-4e4d-b8be-e9e200d7c7a7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33642_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33642_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.171110 10.825764</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33750">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5b7245c9-3fa0-47eb-8c2d-19c9dee1a754</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33750_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33750_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.164653 10.808375</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33751">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b116cf98-66ae-47b9-8931-48ffbbda4981</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33751_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33751_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162967 10.804766</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33752">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0a16e491-5647-48a3-b9c0-1fd1857d478f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33752_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33752_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162697 10.804529</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33815">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>da3948cf-3803-4ca6-971f-36c087f446de</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33815_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33815_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.220317 10.745860</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33816">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3aaf2134-232e-4a5b-92b7-be4e76113b7b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33816_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33816_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.229144 10.757267</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33817">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>72a86495-b7d3-4f28-afa1-cac2c0138e32</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33817_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33817_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.225400 10.750406</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33818">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a1567f86-75f3-4cbf-81dd-7a07674371bd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33818_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33818_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.225124 10.750577</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33819">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8529d8b4-61e6-4932-85d9-ac632d6c3d61</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33819_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33819_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.224678 10.771333</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33820">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>258561f2-7f41-4a1b-a334-2e1415a2b2f5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33820_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33820_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.205018 10.757470</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33821">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>346e49e6-c837-4fdf-b14b-706661942e9c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33821_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33821_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.204549 10.757922</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33822">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>370cd98a-75e1-497a-a7c1-1b07eadcdc2b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33822_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33822_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.204418 10.757415</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33823">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>17477d49-45e1-49c5-9f09-eb133138b7ad</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33823_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33823_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.204456 10.756380</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33824">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>abbc06aa-8a4d-4a45-aaa5-b44d39cd5e0a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33824_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33824_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.204778 10.763035</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33825">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4ca4cd9d-6e35-4f37-abab-99fb5b91f7bc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33825_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33825_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.204277 10.762531</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33826">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4669a27e-fe1c-4416-bda8-d42e3f7b2246</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33826_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33826_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.203426 10.762830</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33827">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>26681ace-f754-4605-a6b7-a618efcdecc4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33827_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33827_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.202055 10.757647</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33828">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4a02a189-1414-4e2e-a4ba-3fef12a28791</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33828_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33828_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.201916 10.758019</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33829">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2158b405-fa88-43a5-b96b-703205bfb918</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33829_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33829_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.201886 10.758409</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33830">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1481686d-b956-4b4e-9f93-d980c566b2b7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33830_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33830_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.202371 10.760514</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33831">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>70f7d3c1-3e0e-4d0b-a5cc-15301b757227</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33831_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33831_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.200484 10.758126</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33832">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>df65aaa8-0dee-4c8c-90b0-a9a35bf0670e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33832_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33832_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.200254 10.758284</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33833">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4baa1dc6-5e78-4e22-a7d7-c490c6262ce1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33833_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33833_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.198908 10.755853</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34038">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7b067359-c224-413c-a12c-ba197b496063</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34038_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34038_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.103688 10.769351</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34039">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>139a4bd7-86ba-4066-b96f-a984627d09d0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34039_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34039_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.103241 10.769137</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34040">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4e8fa43b-ccf3-454a-adc8-5436d204db3d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34040_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34040_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.098129 10.782935</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34041">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9e822028-0bd5-4164-b9aa-6f87ad4c3ca0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34041_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34041_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.097219 10.782538</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34042">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>509cccb4-56a3-47ec-92bc-98d761026cdd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34042_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34042_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.096932 10.782416</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34043">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>88f8a478-e0ed-4610-9d37-5c7387efee72</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34043_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34043_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.098751 10.783056</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34044">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>98565cd5-fd87-4b50-93bf-e7ca172f90d4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34044_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34044_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.104072 10.763540</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34045">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>aecf2cc3-e8e2-4728-92a9-da0981121033</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34045_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34045_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.111200 10.769670</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34046">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>908f5508-8b19-4997-9656-1f3969feb286</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34046_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34046_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172441 10.732905</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34047">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1c719bb0-ea84-42fb-bf7c-5004ffd2c09a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34047_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34047_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172671 10.733306</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34048">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c33d795c-944f-4c9a-8647-7aaf6f8039d0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34048_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34048_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172818 10.732612</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34049">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>665948be-183f-4f62-b6d3-c338552a17c9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34049_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34049_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168791 10.736730</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34051">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2844a1ed-d5bf-4a9d-97e0-0c028c2def07</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34051_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34051_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.169063 10.815316</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34065">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ed137c43-6a93-4bc0-bff0-25abb42f4d1f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34065_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34065_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.156874 10.822838</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34066">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0adc7ce8-29d2-4a27-a708-70b2e222a98d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34066_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34066_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.163548 10.805762</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34067">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a682da7b-ad9d-4410-9167-c9ed759b1f9b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34067_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34067_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179734 10.799691</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34068">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c8d2a7ea-40cf-44f2-98b4-61e9e90a07e2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34068_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34068_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.187914 10.795215</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34069">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>83472c37-1a76-43d7-995d-a7419b66dc49</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34069_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34069_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.186921 10.796425</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34070">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0909e75f-1082-4e67-b057-ef33c819479a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34070_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34070_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162239 10.805009</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34071">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e5b3ad78-1e45-4594-bc60-27970618e41d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34071_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34071_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162291 10.806346</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34072">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>be8bc00c-5f49-454a-822b-a68a12db3c6c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34072_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34072_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162176 10.806012</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34073">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2b136dc3-41fd-4c38-9a5c-e64233891f2e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34073_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34073_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162799 10.807760</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34074">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9268416a-0473-4724-adf8-defa558dcc99</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34074_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34074_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162063 10.807382</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34075">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>dac5acc9-9334-4204-a2bc-b8b92d28ef55</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34075_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34075_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162171 10.808671</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34076">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5d68167e-97e2-4fcd-b7aa-a9a60d966877</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34076_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34076_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162287 10.809339</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34077">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8ea56088-4d08-4883-a441-da7b17de96d0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34077_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34077_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162508 10.809434</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34078">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>46e9643d-388b-48d5-9f5f-8a0a4c394830</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34078_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34078_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162777 10.809480</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34079">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>70ad0e20-41e2-4e40-8afb-86097e7a2a04</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34079_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34079_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.162574 10.810293</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34080">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b15b51a5-2360-4229-bba2-dacc6560edb9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34080_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34080_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.161807 10.805855</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34081">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5f7ba3c6-2c26-4df3-8fd7-6dec5025786e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34081_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34081_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.160236 10.805020</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34082">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b42a8c38-65bb-4636-a80b-7a4cf57b29db</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34082_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34082_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.159223 10.805567</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34083">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3e896d0b-60ac-4f98-bddc-6336f993cd66</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34083_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34083_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.161599 10.814072</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34084">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8cc2a6bd-8f58-4a26-be54-cef20bcea072</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34084_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34084_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.161804 10.814500</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34085">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d376be16-88a6-4e0f-bc1f-5874eadcdde1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34085_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34085_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.161845 10.814994</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34086">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ab67e54f-b506-46ce-8a2a-2fa727be7368</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34086_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34086_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155508 10.805681</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34090">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7320e748-a5c7-4526-81ce-a7e8bfb7309f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34090_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34090_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.152427 10.820634</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34091">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1b429763-2f5a-4604-9baf-ebecb8ea892b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34091_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34091_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.151266 10.815962</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34092">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>99fef97c-3b58-4073-82ca-474f9bfa2834</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34092_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34092_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.156798 10.837014</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34093">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>aa9fde68-79af-4b9b-97e1-02bf67113474</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34093_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34093_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.154072 10.834073</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34094">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ba58fa2d-e70b-4df5-b45d-d4752aef6139</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34094_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34094_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.159645 10.831096</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34095">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>378f16d2-27b1-4082-95c5-f06e46c0fe48</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34095_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34095_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.160682 10.834584</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34096">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e999f158-20af-4161-8b7e-af7bcf0fcb98</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34096_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34096_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.160618 10.833694</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34097">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3a866060-36de-4e0e-8943-c8cb242eb612</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34097_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34097_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.166528 10.845426</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34098">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3b4044a8-2c25-4e17-ab3b-082e30dd93c9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34098_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34098_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.166466 10.845453</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34099">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6f977b08-68eb-441f-baa3-479ed9facd74</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34099_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34099_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170084 10.855037</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34100">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>803eb6de-f7c3-4b73-846e-f3e9dc2fa2ec</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34100_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34100_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.167783 10.860541</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34151">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c7adb32b-eee4-4633-b70b-8a2a389dca32</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34151_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34151_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.196387 10.770688</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34152">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1bd8de55-c7b8-4fdd-b234-c2b38c12979e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34152_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34152_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.196242 10.770435</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34153">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>43e2fb0a-ed29-4229-b24f-7c4cbeef66df</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34153_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34153_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.192841 10.767201</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34163">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>395f03a7-b0c4-42e4-b07f-c66ab3c362b8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34163_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34163_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.167518 10.799587</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34164">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8c7f871a-e07f-4a23-b124-00b276b5c0f3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34164_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34164_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.167648 10.800931</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34165">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2b4d8a24-ba36-4338-ab65-0f80a1f1c00d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34165_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34165_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155264 10.805327</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34166">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>07778d1f-c5d2-407b-8970-bb7bed043f25</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34166_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34166_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.154334 10.805281</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34167">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8417475a-833a-4368-b647-7a6074e3d84d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34167_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34167_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.187166 10.786925</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34168">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9ca5c928-1191-4f94-a3da-1c885d231253</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34168_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34168_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.186499 10.788335</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34169">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f4667e1f-4a77-451b-9763-585daea01939</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34169_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34169_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.185491 10.788053</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34172">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>dcc3535c-124d-4c2c-baf8-956f59adc8e3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34172_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34172_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.201022 10.758324</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34262">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b3d14134-0c97-4a19-9079-998b691a5f25</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34262_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34262_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.198006 10.783842</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34280">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>99bbb1ed-ec6e-444b-8fde-f98781c74415</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34280_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34280_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.157603 10.812605</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34612">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f3c6beb4-0654-42ad-bfe5-5d777492e26d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34612_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34612_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.236819 10.760142</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34613">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>506e2bcd-29d7-4265-ac11-1e822c81d104</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34613_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34613_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117517 10.837085</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34614">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9702e3b4-44e2-4edc-87ab-4150c19026d7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34614_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34614_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117624 10.836945</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34615">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>bf57105e-6b87-4be5-b368-fd3b6599e691</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34615_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34615_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116326 10.837949</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34616">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2cb9acb2-f3c3-43d9-80ff-390ab8ce434c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34616_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34616_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.122031 10.846193</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34617">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1416c9e6-2d6c-4bad-a500-13f23040ae0c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34617_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34617_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.122277 10.846121</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34618">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ad0003bf-ca1b-4339-823b-c6b030397ca1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34618_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34618_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121581 10.843074</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34619">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>df6f9e04-629f-4cfa-9f54-b9c41e9f681d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34619_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34619_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117215 10.839885</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34620">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>99052817-e8b1-4d44-ae47-1ad660928a03</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34620_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34620_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117307 10.839902</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34749">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>33b7c375-de48-43c2-84d7-20b32c46627d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34749_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34749_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168152 10.801475</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34750">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>22b0eac0-2227-4b8e-a4f1-ffa473dc9b3e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34750_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34750_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168579 10.805209</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34751">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>15334c55-5e4d-4cb5-843b-882f939f43e2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34751_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34751_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168486 10.805779</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34752">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4b0eac30-6878-4b39-a0d6-0410141bf79a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34752_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34752_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168323 10.806054</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34817">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>eb740f5b-f329-4781-a4e9-a9d9bd380971</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34817_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34817_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.230297 10.733042</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34845">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6baaeb5b-a149-42a0-aa35-290ede7c20f7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34845_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34845_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.167951 10.807560</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34846">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4d577566-e6f9-4510-90e8-1d9af198ff0f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34846_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34846_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.167800 10.808540</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34847">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ccd6cd5f-7089-4081-8baa-d8965904fd12</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34847_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34847_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.167296 10.808065</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35104">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3055db23-4f8a-4dd5-afdb-e3fef3e7e249</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35104_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35104_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.092516 10.841011</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35105">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>760d70cd-16cb-4508-bdd1-49bf840fb056</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35105_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35105_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.093814 10.836133</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35106">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f92d06b4-6c6f-4e10-bb47-5e88cb39913f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35106_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35106_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.097776 10.828615</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35107">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>93222a9e-b401-4a29-adfd-09603740d71c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35107_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35107_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.100965 10.814845</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35108">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>01828b0e-b046-4e9f-8f1e-16177438f113</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35108_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35108_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.101337 10.816074</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35109">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f8be78ca-ef2e-41e4-a47c-f176c5d4968b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35109_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35109_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.104792 10.832462</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35110">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2f6850bd-2af8-4b09-bc4a-02e21ec67892</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35110_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35110_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.106415 10.828116</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35111">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>24fd2576-4937-4e97-8edb-5f75a88a3073</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35111_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35111_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.113419 10.851909</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35254">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c38e0192-60c6-440b-8141-90d47976a9f6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35254_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35254_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.157343 10.812708</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35255">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>53819569-68c2-41c5-a075-d23f38bde096</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35255_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35255_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155533 10.816710</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35256">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a3825971-cd3b-491d-a963-45cc5d22b8dc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35256_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35256_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155272 10.816610</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35257">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e9ae5731-c50b-493b-b7c9-89b775d7c1c6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35257_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35257_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155313 10.815070</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35258">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8767eed0-c29f-4425-807d-1f85f65a74bd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35258_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35258_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.154739 10.814820</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35259">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8f1f62e3-a28c-4a5c-a340-9cda01bb19df</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35259_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35259_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.154470 10.814770</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35260">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a67ae95b-d280-48b6-a6aa-5b67121dafbc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35260_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35260_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155687 10.821480</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35444">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9a8c1df9-47e0-4015-b5ed-6a8354054cb9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35444_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35444_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.212949 10.790938</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35445">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5ba2b2b0-aa76-45bb-9975-2fe77c88882e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35445_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35445_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.212297 10.793262</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35446">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d9756cee-c915-4f30-a169-56e3ac481bce</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35446_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35446_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.212387 10.793577</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35447">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>45cf00de-751f-486e-8fa3-3a6929d9a0fc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35447_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35447_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.212055 10.793515</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35588">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>659db4f4-e9f5-4b92-ba5a-e2e663cdb900</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35588_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35588_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.225200 10.757940</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35589">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>bf2f1887-210e-49ed-a0d4-ad0df4cd1a4e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35589_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35589_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.224984 10.760481</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35590">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>deba4621-fd21-4743-8398-a03cd7a8888a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35590_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35590_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.224377 10.762322</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35591">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>70ad671d-9f75-4a47-9eb4-cf6869c42c46</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35591_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35591_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.224978 10.762317</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35592">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3d66fd44-d5f9-4b98-84ab-6d348038ca22</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35592_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35592_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.228878 10.759301</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35608">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c36fcb4e-c45c-4ae9-9a78-f0eae0ccee17</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35608_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35608_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.115587 10.844885</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35609">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b2ddc29d-e17e-45de-8693-14de8b6d18aa</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35609_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35609_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116921 10.845807</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35610">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b1a69dd2-817f-4a84-8bae-1dcc97db4770</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35610_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35610_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116179 10.847148</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35611">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>45c7c414-1d61-4de7-b343-dd7cd4195031</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35611_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35611_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117130 10.848448</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35612">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>dc45dc7f-f94d-4740-a9eb-2888d7c86732</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35612_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35612_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.118324 10.841336</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35613">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ce0aeee5-07cc-41b6-b8a9-e914d6ce0f99</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35613_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35613_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.120678 10.840853</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35614">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>76fe2e6b-8077-4943-9fec-c808ce963ff0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35614_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35614_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.124707 10.863197</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36128">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5e7282fb-7800-47e3-b264-e405486df9bf</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36128_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36128_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.217915 10.786283</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36129">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c8126e2e-058f-48f3-bfd9-3525433653f6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36129_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36129_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.212404 10.783818</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36130">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e6aab97f-bc44-4e7a-8f26-e118846bffa2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36130_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36130_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.184657 10.780884</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36131">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>91624673-de2e-4c39-bf94-f281f4c05406</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36131_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36131_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.181973 10.782126</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36132">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f7073bde-cb58-4b12-afd8-88c96af5d0e6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36132_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36132_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.181673 10.781758</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36133">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>197f1797-f2a3-45e3-a607-864245a4a219</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36133_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36133_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.181304 10.781858</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36134">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f847f00b-3027-4304-ad5b-7ac5b154ace3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36134_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36134_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173850 10.792383</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36135">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>39aec2fa-efe0-446e-b9a4-5ad8c82e7152</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36135_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36135_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172663 10.793180</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36136">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>06396051-a968-4e8a-a55e-5335dc911891</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36136_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36136_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173469 10.793938</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36137">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4f1f9755-3de4-4b94-8991-3b511e67598f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36137_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36137_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170851 10.793170</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36518">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f4373bc6-249c-41b6-be75-d49a8564ae00</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36518_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36518_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.224229 10.737093</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36519">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5ab552c1-f54e-4df2-bfc0-e9630fb23270</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36519_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36519_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.225376 10.736777</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36520">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>50813686-fcac-49c4-9912-069ff7de4b81</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36520_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36520_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.226132 10.743968</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36521">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ef763217-9d8d-4125-8ab1-41733ae6a3a4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36521_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36521_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.103272 10.761794</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36522">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8e0ada06-a3ef-4a92-93b8-6df46b7a2273</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36522_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36522_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.169402 10.718165</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36614">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>05d03a4b-3f9f-4d58-b1b0-4c3b0edad0ad</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36614_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36614_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.220335 10.746194</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36615">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5949ddd2-b394-4e27-bd47-70dccfec1045</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36615_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36615_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.217411 10.745487</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36616">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5d6379b8-9270-44d1-89c8-3acf67d66f9e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36616_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36616_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.216999 10.754642</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36617">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>32de2ff6-d1da-4392-82dd-ff5e997ecd4a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36617_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36617_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.215461 10.757695</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36618">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3d7f13f0-137e-4505-9dda-b1f6551ab344</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36618_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36618_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.224177 10.757302</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36619">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>795580e5-3501-461e-9d1f-7309d6ee9225</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36619_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36619_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.224889 10.757493</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36778">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8faa3eb8-eb5e-4ef5-a26e-597572027ec1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36778_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36778_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.171517 10.733505</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37072">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>23bed724-3aa9-4a12-a743-e3c91e4e7fd2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37072_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37072_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.207541 10.765801</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37073">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5bf203ec-e966-4f5d-93fa-0da22f42c949</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37073_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37073_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.209083 10.767248</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37074">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0dd6e1c9-cc0e-4ac2-bed7-9d3769b5efcc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37074_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37074_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.199876 10.767209</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37075">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c26ae970-ae48-49f0-87dd-f463890ba6df</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37075_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37075_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.198891 10.766708</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37076">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>da35e285-0eac-48a1-b128-9e41ebf138cd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37076_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37076_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.197162 10.767128</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37077">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6b6d0b75-bb45-4cb4-9b41-ed7a1a3f7483</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37077_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37077_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.194497 10.765750</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37078">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b7f5ceb3-7295-4be0-bbd9-88019f4ca712</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37078_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37078_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.194237 10.766372</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37157">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7ce8b830-d7fb-4997-a6f5-07e86fb8ce00</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37157_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37157_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.195854 10.781738</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37158">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>416f4174-c39a-462e-b5b4-c57b466a6201</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37158_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37158_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.195382 10.780894</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37159">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>76abe105-22b5-4e9e-b253-d65758d50802</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37159_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37159_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.194188 10.779284</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.47316">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>93767539-c493-4125-a840-66d9daca6a28</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2016-05-03T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:58</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.47316_APP_POSISJON'-->
        <gml:Point gml:id="skjer.47316_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121881 10.854015</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.47318">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>df3afd22-95d3-4d61-8ae8-a04a58e4a6bb</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2016-05-03T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:58</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.47318_APP_POSISJON'-->
        <gml:Point gml:id="skjer.47318_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121772 10.852846</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.50095">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>feaf6b72-9470-445b-b040-71fb6a3aa316</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-06T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.50095_APP_POSISJON'-->
        <gml:Point gml:id="skjer.50095_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.261673 10.726386</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.50096">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1902ef0d-ac3e-4539-be1b-7a007ebebf0e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-06T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.50096_APP_POSISJON'-->
        <gml:Point gml:id="skjer.50096_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.263853 10.728695</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51285">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e82218e0-024a-4a24-9182-538060d75f8b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51285_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51285_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.245490 10.734999</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51286">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2a77077c-8c5f-4673-ac1e-4b7208770184</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51286_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51286_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.230163 10.704451</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51287">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f222cdc5-2186-4c7d-91ed-3c78daf1d34c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51287_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51287_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.227122 10.701718</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51288">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5e74c5d9-1364-4f44-94dc-406ac1e76595</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51288_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51288_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.229439 10.704476</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51289">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6fa7a19f-22be-435a-84d8-3cea3684d609</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51289_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51289_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.218523 10.733814</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51290">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fd4947ac-e77e-4737-85f9-be2650826ae3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51290_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51290_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.239691 10.701213</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51291">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c947eb42-4788-4954-954f-e96106fb056f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51291_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51291_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.239535 10.701154</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51292">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e25f01b8-05dd-423d-86d8-b5320b88d179</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51292_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51292_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.246842 10.731312</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51293">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4bdd02b7-1ea4-4d86-832b-407cdb19f4b5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51293_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51293_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.222397 10.732717</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51294">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>83368998-2c98-46bc-8612-c21ffc2592bd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51294_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51294_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.246496 10.733775</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51295">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8caa3b5a-eb27-40a3-b219-67ec2a5c8c2e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51295_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51295_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.237594 10.731231</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.51296">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>21de98ea-8413-4e60-8b6f-c2c1b331f33f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2019-05-15T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:10:00</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.51296_APP_POSISJON'-->
        <gml:Point gml:id="skjer.51296_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.233062 10.730015</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32418">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>51644ed0-2161-4f38-ba01-1b07cbc11ed7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32418_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32418_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.115347 10.985784</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32787">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2722d0a8-6ed2-4e95-b3e6-ccd6101506f2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32787_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32787_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.114694 10.986341</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32788">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b46ce22b-adc7-4928-bc6d-d3a29e9a26ad</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32788_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32788_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.114487 10.987457</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32789">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>57697d51-942d-4006-879f-a1a2fe13ce5e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32789_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32789_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.114556 10.989072</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32790">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ef489711-1e0f-4dec-989b-24d98b4cc7cb</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32790_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32790_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.114774 10.989283</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33441">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6dbbc37f-fa0a-476f-87d6-446a066a604a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33441_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33441_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.137403 10.999114</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33657">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>286242f1-6b22-40c8-920b-1678973ca661</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33657_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33657_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165116 10.990234</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33658">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ce82d6e1-05e8-4388-a4fa-e91aa4eb24d3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33658_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33658_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165736 10.990195</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34673">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>52dbe1fe-632d-4b08-85c0-5c591e2700fc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34673_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34673_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.151039 10.995767</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34675">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e749360f-a8f0-486e-b5a0-cd070db7b7ee</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34675_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34675_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.148809 10.989592</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34676">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f73e24d2-0d36-4b87-8f9c-ecafc2fcd99b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34676_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34676_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.148809 10.988675</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34677">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>290e73ce-315b-4290-bf42-78db25b77e0a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34677_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34677_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.146318 10.988020</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.31853">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>06fb4a98-ee15-43a1-a7c2-64cf561c9080</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:46</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.31853_APP_POSISJON'-->
        <gml:Point gml:id="skjer.31853_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178030 10.882157</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32251">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>60ef0b4a-fcf8-4bd4-a316-8b547756d35c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32251_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32251_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.129835 10.931175</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32252">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>52353e15-abcf-4804-b347-182da3e23bbb</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32252_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32252_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.136769 10.932586</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32253">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1ea2ac4a-035c-4b15-9ad2-2a7d2b05744d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32253_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32253_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.135449 10.934878</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32398">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9247cce3-4d15-46ad-8e15-837bf2b154db</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32398_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32398_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.133307 10.930916</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32399">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8ba9b453-148d-4430-aa66-6e6ea998b92d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32399_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32399_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.132877 10.926474</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32406">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ee80425f-2d64-4fe7-9398-f3e48d482d75</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32406_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32406_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.112066 10.877264</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32407">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fab4d4b3-af69-49e2-beab-b7ed258d503c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32407_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32407_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.114390 10.879033</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32408">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d0bce424-fefc-4a08-98a9-d1490ee58ec0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32408_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32408_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.113586 10.888437</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32409">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>30a048df-cf45-4fe5-b082-64709d67fcba</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32409_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32409_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116982 10.905360</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32410">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2fbd1d46-4be5-48fb-9e54-ae738282c81c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32410_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32410_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.129883 10.950675</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32411">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c8089b7a-e2b4-4171-989f-9484928e79df</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32411_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32411_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.130877 10.937630</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32412">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>25edd979-b5be-45c1-b57c-3d3b30071a69</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32412_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32412_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.129927 10.938894</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32413">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b679cd08-ec14-4d34-a43d-6418e67c77c6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32413_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32413_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.128311 10.934888</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32414">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1260d4ad-e4ec-493b-972e-b16aba61201d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32414_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32414_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.128970 10.926421</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32419">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c03ba629-f1a4-4f84-83f0-ae17accdaf6a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32419_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32419_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127382 10.891374</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32420">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9fd7e61d-8b33-411f-a2e0-40c0ba10a10a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32420_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32420_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.120195 10.894160</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32421">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>27b588b9-c24f-418d-bf64-6109192973ba</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32421_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32421_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.122201 10.897221</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32422">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9c1d9c6b-b9b1-45e8-910f-fe1e248ba29f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32422_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32422_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.122126 10.896447</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32423">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a750c9cd-31b3-4a7b-85c7-73d424b0caed</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32423_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32423_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.122229 10.897780</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32424">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>11393f05-c712-4f1f-9953-2147bfd93878</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32424_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32424_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121130 10.903154</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32425">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>626a1474-a840-4de7-bad1-7999d9c864e7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32425_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32425_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121279 10.903442</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32426">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c7e92009-d86b-4569-bd06-d712abb83e73</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32426_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32426_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121315 10.902901</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32427">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4a653d2d-ca52-4387-94c5-0a1860de4216</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32427_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32427_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.128285 10.898609</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32431">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8c056e1e-4491-4439-bf69-9c75348d2f43</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32431_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32431_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.089195 10.938619</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32816">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>eafcf1d2-20b3-4b37-b8a4-8195b35ae24a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32816_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32816_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121977 10.909851</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32817">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b9812d9c-b91c-4974-8fbc-e3eb8e6c11e5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32817_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32817_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.122053 10.910826</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32818">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>edd39103-019c-4ea2-b275-258241399ba4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32818_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32818_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121779 10.909478</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32819">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>15322ade-f7bc-445a-9289-a2735513e3e5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32819_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32819_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.118286 10.910677</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32820">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2061584d-404b-4a92-8d5c-7e67fa262a9d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32820_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32820_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.118565 10.910388</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32821">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b96182c2-0279-4bd4-899a-2a866687b051</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32821_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32821_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117246 10.914001</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32822">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7dbec05c-8e94-4a60-a3de-5925e3bcdeff</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32822_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32822_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.120963 10.917086</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32823">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>851d026a-e7ba-4c9b-9262-b6d479f11688</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32823_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32823_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.120721 10.916893</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32824">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9b3ad00f-6834-4b8c-87b6-6eb02328a00a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32824_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32824_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.123108 10.920246</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32825">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>48170b58-8bd3-486e-81a7-81ccf86a93d9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32825_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32825_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.123557 10.915351</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32826">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7c6fceed-9796-4d7b-9849-2866cad556a4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32826_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32826_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117096 10.919027</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32827">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>80e368f9-a68f-4e7d-9154-4862257b00bd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32827_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32827_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116868 10.919000</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32828">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d6356525-9237-4e8d-abc3-712bd13bedec</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32828_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32828_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116738 10.919938</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32829">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b611c3b6-9364-43db-a71b-7b67cc8b42dc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32829_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32829_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116573 10.921050</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32830">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3887db25-6f6f-4a1c-aeea-e54d10a3014b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32830_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32830_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116973 10.921813</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32831">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>9e476897-9bf4-4122-88c7-62142c3ed777</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32831_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32831_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117421 10.921973</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32832">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>20cdcc36-d96e-48a0-9b75-b071be41360d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32832_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32832_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117510 10.921544</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32833">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ed620bbc-e568-41c7-a77f-f69a3ad6e1c6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32833_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32833_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117517 10.921075</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32834">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d6617dae-4d36-4418-90a0-443b218ef000</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32834_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32834_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117813 10.920940</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.32835">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7fe2eb19-9b5b-43a9-aed7-83ee0912f39d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:47</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.32835_APP_POSISJON'-->
        <gml:Point gml:id="skjer.32835_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117978 10.920659</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33427">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>295f5ad9-da28-4bd8-860f-f93a36d2ac5c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33427_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33427_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.128344 10.898780</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33428">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>af6ad811-c666-4497-8cda-4db49f9b8441</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33428_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33428_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127502 10.900175</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33536">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b13f9e82-38f6-4fb2-94ee-460a5d97c5b8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33536_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33536_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.149073 10.892204</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33537">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>39ab36e6-f43b-4054-8dec-6b93786b71db</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33537_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33537_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.146873 10.895175</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33538">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>23ab8c51-2706-4f24-9cab-b074d4a7648e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33538_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33538_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.144793 10.900697</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33539">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>cc5deb6c-826f-4982-98de-84aa9087e9cf</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33539_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33539_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.143506 10.903501</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33540">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>bc3dd0eb-204c-4c26-b660-24333703bf19</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33540_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33540_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.140643 10.898502</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33541">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0631f353-056a-49f7-8e88-0ea3d8982c65</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33541_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33541_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.140174 10.906922</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33542">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e46565b7-d4b8-43fb-99e5-122400602d04</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33542_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33542_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.140030 10.913299</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33571">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4b4a7dbc-e0da-4d42-8d3d-0563e0284a2e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33571_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33571_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.163494 10.902198</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33572">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>253a566a-1b17-483f-b625-d99c9c41c75b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33572_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33572_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.163760 10.902042</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33644">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b05e2f6c-2e10-4b15-ab6e-1efa5c94459e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33644_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33644_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.137591 10.911864</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33645">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>66108068-2097-404b-b2ef-c27e319c1ccc</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33645_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33645_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.137355 10.911504</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33646">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>55404f3d-b91b-450f-8728-849fb90bc7c1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33646_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33646_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.136860 10.909524</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33647">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c542c749-d7ab-45ea-8373-fc2683c1c78f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33647_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33647_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.136506 10.918771</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33648">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>075542a7-2a1f-4bb5-a42d-f2d1efbbc06c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33648_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33648_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.128612 10.893643</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33649">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>90fb1cff-e395-4847-b3f7-267dcc1d9383</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33649_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33649_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127690 10.892655</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33650">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a388bffe-9c36-4d26-ab02-14de790f4ae3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33650_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33650_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127944 10.892479</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33652">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a893c1a9-17fa-4c51-a2d7-3d125e64f7e1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33652_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33652_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.109033 10.965714</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33654">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1c4e7e0f-e73e-442c-a6e2-fc3c7d2ceff1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33654_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33654_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.106389 10.965085</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33656">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fc8ca2cf-f203-4f5b-be00-eb0272919f66</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33656_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33656_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.169903 10.969022</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.33689">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f205bff5-0890-493a-8a38-d69f654573dd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.33689_APP_POSISJON'-->
        <gml:Point gml:id="skjer.33689_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.094210 10.915071</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34052">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0201398d-e9ec-4509-8417-a4475e732235</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34052_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34052_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.125439 10.911446</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34089">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a2350865-8fac-44f8-9f7a-8d55def028f6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34089_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34089_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127552 10.901662</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34101">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5989cf31-2d56-4b4d-8c84-4521b7520ba1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34101_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34101_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173709 10.894072</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34102">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c017a237-d8ca-4e13-b9c2-75de152dfb6b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34102_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34102_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168567 10.888812</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34103">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>999aa7ba-7998-4514-ab55-b02edb15e7e2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34103_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34103_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.116852 10.926675</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34104">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c3f33801-eb9d-4d1c-ab05-7c0a1e77b47d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34104_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34104_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.115145 10.929036</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34105">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2f8b7f89-0fe7-4c92-b97b-a3307ed1cb46</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34105_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34105_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.119197 10.932263</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34106">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2eaaf36c-7270-4159-a95e-3a18e26b491b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34106_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34106_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.119137 10.931651</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34176">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ae9812e1-3729-4970-94ad-835f6d56edbb</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34176_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34176_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155058 10.899942</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34177">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6e854ba3-218b-486b-b2b1-4977be5f8d97</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34177_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34177_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155472 10.901988</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34178">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0f768ab5-c1b4-4674-a1fd-978a0f0caf36</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34178_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34178_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.155991 10.902116</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34179">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5d2f308d-d3d1-43a4-bc06-981e2c697158</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34179_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34179_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.151159 10.919067</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34180">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>074b8e38-b488-4f86-b4fe-c44ac1722575</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34180_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34180_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.150787 10.919560</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34181">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e7448642-0574-4cbe-bea4-be25103472c2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34181_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34181_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.148232 10.896060</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34412">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>866d2e10-582a-4279-a6fc-4356e2ddc44e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34412_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34412_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.124287 10.868208</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34413">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d64ea9d3-997c-4b6d-b89c-a4f2e130557c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34413_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34413_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121852 10.869153</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34414">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a4769b7c-02ba-451b-815e-eb58133e233b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34414_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34414_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.122576 10.870349</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34415">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>05b1f2ad-0af1-4c2c-ac76-8bc94d0b56bd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34415_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34415_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127973 10.887168</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34416">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>910f79cc-e872-4ffd-9693-e9092b8e8f76</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:48</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34416_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34416_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.128438 10.888050</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34678">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a352ef16-9dd4-46c5-a27d-caf3462c7260</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34678_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34678_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.145613 10.976055</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34679">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4b0e315f-45b9-4ad8-957b-65b096400daa</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34679_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34679_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.129046 10.906006</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34680">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>070b0731-7e10-4f9b-83ad-781d6e324d07</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34680_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34680_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127919 10.906791</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34681">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>25f7cb8a-6599-4927-b9e5-d8f59a16e7ba</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34681_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34681_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.130193 10.907129</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34682">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e85dd4f5-252a-42ba-bb44-e8cc1fe2ced8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34682_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34682_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.133473 10.900673</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34683">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>dd98d5c2-1d15-45c2-ba25-95024e7bc09e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34683_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34683_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.129623 10.909778</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34684">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ee3a3486-f618-4514-bec2-385b7f737eca</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34684_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34684_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121691 10.907705</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34757">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>73503ac7-e434-4482-b1fe-0d2d5899b60c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34757_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34757_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.126857 10.918814</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34758">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e93f4337-a1cc-49f3-a7b1-b7289b65c3a6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34758_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34758_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127216 10.919331</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34759">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>34a07221-79be-4e5e-9a75-ceddde954172</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34759_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34759_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.128765 10.923650</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34760">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ff2b9ad7-6c79-428d-b0d9-bf76b5c6fb7f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34760_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34760_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127461 10.918234</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34761">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b8d8c197-e698-484c-87ae-4f8155afe1db</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34761_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34761_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.127584 10.918533</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.34762">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>31974f77-a634-43f7-9c33-eeb7cf2077f5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.34762_APP_POSISJON'-->
        <gml:Point gml:id="skjer.34762_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.132053 10.930083</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35129">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b3035814-8f50-4637-b87f-352f2acb4ac0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35129_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35129_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.112940 10.945448</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35130">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>49f2683e-0ac9-4ce2-b22a-c3a2a1e45bf0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35130_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35130_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.110748 10.946156</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35131">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>918a277e-879e-4e1a-90c6-b04112e2e27b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35131_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35131_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.119628 10.940573</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35132">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>79edaac8-f696-4933-9968-f3fdfb6351b0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35132_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35132_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.117829 10.936555</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35133">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7766c645-0a94-495f-9345-087727b260f5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35133_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35133_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.123247 10.938541</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35134">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3b3f8181-4d01-462a-965c-556b30860ae4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35134_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35134_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.124321 10.943768</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35135">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>21e48142-62b8-41e4-b701-73f5aa48741d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35135_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35135_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.124581 10.943964</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35136">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>35e95c35-9142-4004-9636-1e6ed7d89236</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35136_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35136_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121803 10.949511</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35137">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>da3f731c-73da-43c1-9324-5f941dfdc7a7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35137_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35137_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.109802 10.957272</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35179">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ac14a410-ed55-46db-9a8e-bb02f64d3fe1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35179_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35179_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.090431 10.962940</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35242">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3f972a7b-b79d-482f-9d92-5659a362cac1</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35242_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35242_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.110251 10.957853</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35243">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8521925e-32ae-402b-9499-9c271893c97b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35243_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35243_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.136508 10.963624</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35244">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>cbdac73f-f502-423a-80c2-f81515cf6bb9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35244_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35244_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.136299 10.964109</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35245">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>27b1fa0b-fa81-47be-9ae4-47e047d20587</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35245_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35245_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.135870 10.965856</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35246">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>afd565f7-df71-49d6-a8d9-9574680e8efd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35246_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35246_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.110225 10.965584</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35247">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0b1614bf-4421-4f28-bb85-9256c0759bad</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35247_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35247_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.109940 10.964928</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.35248">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>facf371c-c706-4c0d-8b9d-bc82e404593b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:49</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.35248_APP_POSISJON'-->
        <gml:Point gml:id="skjer.35248_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.109357 10.964954</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.36516">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>16403a70-92fc-4663-aeab-14b82fda383c</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.36516_APP_POSISJON'-->
        <gml:Point gml:id="skjer.36516_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.118597 10.954439</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37286">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>cec7b729-6537-4f68-ad78-f9c023c17540</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37286_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37286_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.118397 10.930825</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37287">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>277f5552-ac99-4813-a530-be2e7f19f922</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37287_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37287_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.111062 10.932030</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.37288">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e9ed3c59-c8a9-4b6d-bb9b-ce2574ee27c8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2005-07-31T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:50</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.37288_APP_POSISJON'-->
        <gml:Point gml:id="skjer.37288_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.111473 10.936163</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.43887">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>42b73ab4-12e4-4220-ae20-653e8feb1e1d</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.43887_APP_POSISJON'-->
        <gml:Point gml:id="skjer.43887_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.164183 10.883524</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.43888">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5ae41be9-0ad6-4d14-839f-57e48a217eb7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.43888_APP_POSISJON'-->
        <gml:Point gml:id="skjer.43888_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.164091 10.884898</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.43889">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>f8618bc7-27e5-4a20-9347-aaefe78cceea</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.43889_APP_POSISJON'-->
        <gml:Point gml:id="skjer.43889_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.164840 10.886092</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.43890">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>214777af-c030-40fe-bf86-d191d5d188c5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.43890_APP_POSISJON'-->
        <gml:Point gml:id="skjer.43890_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.164858 10.886127</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.43924">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b8fed134-d763-48b2-9735-85f89054ceea</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.43924_APP_POSISJON'-->
        <gml:Point gml:id="skjer.43924_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.175152 10.887750</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44030">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a9a9524d-8098-4bcc-b1e6-1b1c26b1504e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-08-19T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44030_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44030_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170453 10.893091</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44129">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>79d81e84-e566-4d89-b2bc-2e1407037054</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44129_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44129_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165960 10.888465</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44130">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ca772b89-aba2-481c-8ea5-d8114be77a6a</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44130_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44130_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.167189 10.888003</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44131">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>1257fb07-2465-4e21-ad8f-29b168e268f8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44131_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44131_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.166317 10.889410</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44132">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d1179cc5-44a8-4cf9-acde-78d712d9a272</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44132_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44132_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168603 10.891444</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44133">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>757dac06-0a94-4660-8e18-f9e20be6a515</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44133_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44133_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170217 10.892542</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44134">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6d2d005c-7ec5-46ad-9257-ba14dea346b8</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44134_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44134_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.170199 10.893412</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44135">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>de5b432a-d9f7-41d1-8478-12752b59a342</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44135_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44135_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.166091 10.891221</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44136">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>67d74e94-91e9-40db-8c5c-9e5ef38a7d52</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44136_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44136_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.166060 10.891247</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44137">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>5888358c-347c-46f6-ba04-fa4506aee679</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44137_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44137_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165747 10.892249</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44138">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>69d55c33-90e8-4311-8f52-7a4ee98bda97</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44138_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44138_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.166768 10.892511</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44139">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4269b239-89d6-48c3-8166-b7804381c2c6</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44139_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44139_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.167127 10.893946</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44140">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d3605f04-0e55-4ffb-8d1e-7eba20e367f3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44140_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44140_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.166796 10.895843</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44141">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>792775cc-6964-427a-a555-671df6ca5bcd</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:55</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44141_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44141_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.164909 10.898434</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44361">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b8158dd8-e629-4d91-ace5-abacad10aa6e</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44361_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44361_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165322 10.903984</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44362">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a8f3ce10-5179-44b8-a77e-6a659226e1ea</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44362_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44362_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165491 10.904136</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44363">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a4488d27-9c90-449b-ba84-99dcf6c06bb4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44363_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44363_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165295 10.904251</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44364">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2ef1bdcc-c981-4632-89ac-ac27d7f53871</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44364_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44364_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165039 10.905832</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44365">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>e9eaa8c0-db8e-402f-80c8-a6e9b2df0944</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44365_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44365_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.164931 10.905897</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44366">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>19431900-d00d-4c83-91e7-02f1cd97a473</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44366_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44366_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.168419 10.905742</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44367">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>48a1a7f6-d54d-479a-ab8d-b1d9f1d3f9ba</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44367_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44367_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.169564 10.899612</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44368">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>69029a21-aac0-4b40-8d50-028ef21b20e0</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44368_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44368_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.171687 10.899096</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44369">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2473cfcb-d867-4a0d-b0c0-a7755fd3608b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44369_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44369_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.176463 10.903322</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44370">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>685356b8-9216-4efd-8b30-ebaee0900760</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44370_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44370_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179601 10.898211</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44371">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>389e3351-4321-4b6c-a5b4-55e0b95db41b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44371_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44371_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177830 10.896910</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44372">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>eb4be785-413a-4fcb-aff4-e847bf5494ca</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44372_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44372_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177778 10.897059</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44373">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ff15e706-fe76-486b-b563-6b8adaebe5f9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44373_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44373_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177670 10.896779</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44374">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>26750923-857d-4a19-a625-ff10d1e1ad76</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44374_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44374_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177681 10.896724</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44375">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>62e96d39-bde6-4a15-b5b7-ebd5ae7c9400</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44375_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44375_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177616 10.896544</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44376">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>733233af-00fb-4e82-90f1-b7a27980ed3b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44376_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44376_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.176463 10.894564</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44377">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>3af8f2d0-18f6-4559-93fa-7fdeb0deae92</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44377_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44377_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.171519 10.894614</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44378">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>8116a956-c69b-46e5-8e00-1c39b6010606</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44378_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44378_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173663 10.893049</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44379">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>90b7252b-98b5-4b31-99ac-c4167952eb62</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44379_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44379_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.173563 10.893508</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44380">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0f0ce53d-b611-4480-8e79-6a56ea08df0b</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44380_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44380_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172050 10.892137</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44428">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>64d1d50d-a2d1-4046-b487-21a0792db7c9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44428_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44428_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172035 10.891204</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44429">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>b7bfab92-ab19-4ec7-89aa-506908f8cfa9</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44429_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44429_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.171203 10.891034</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44430">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fee66049-1575-4bf9-8a97-ab4a3ea9a544</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44430_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44430_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172186 10.889934</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44431">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fdd0047e-00b1-43ef-bb22-f25751a733f3</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44431_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44431_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.172184 10.890075</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44448">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2c5265ae-12b8-4eda-aea2-0cb1f8890a17</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44448_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44448_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.174614 10.883990</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44449">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>2810e5e3-5d65-423f-a3d1-5c91fbe3d8b4</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44449_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44449_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.175741 10.881857</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44450">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>a183ce2c-ded6-4541-8798-aa0276acfd85</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44450_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44450_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179459 10.871963</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44451">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4daf2b20-9919-453d-a83f-311b66680e44</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44451_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44451_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178764 10.867074</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44458">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ff8ac340-5c79-4a99-9816-856d25e8d527</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44458_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44458_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.178500 10.867013</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44459">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>729d9796-ef6f-4ad0-8396-b849afca1eca</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44459_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44459_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.179710 10.866974</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44460">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>539f7014-f3fb-46a7-b9fd-5e3de3d6a7ec</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44460_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44460_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177733 10.876328</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44461">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ca37c62c-ff27-47b3-8af7-d0afd9a622e5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44461_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44461_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.177806 10.881178</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44462">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>0a45be7e-dbdc-4b0a-8e32-b51b7fc3bb86</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44462_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44462_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.164859 10.972566</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44463">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>6d26c42d-2ae8-414a-88a7-fecfaddcfbb5</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44463_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44463_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.166941 10.976914</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44464">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ee8418d1-2576-47da-85ec-ef5356a3fe25</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44464_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44464_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165829 10.976703</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.44465">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>d213ba60-dbbf-4ca2-bf38-513cad5482a7</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2013-06-30T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:56</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.44465_APP_POSISJON'-->
        <gml:Point gml:id="skjer.44465_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.165803 10.976791</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.46914">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>4deefbb7-6cd4-44cb-b445-f78f88ef7669</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2016-05-19T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:58</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.46914_APP_POSISJON'-->
        <gml:Point gml:id="skjer.46914_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.109961 10.930026</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.47315">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>ce289ac4-33ca-4160-bc21-e7a016bb6f7f</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2016-05-03T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:58</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.47315_APP_POSISJON'-->
        <gml:Point gml:id="skjer.47315_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.121084 10.851895</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.47317">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>c618f86f-8664-4351-b373-a450509faf15</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2016-05-03T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:58</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.47317_APP_POSISJON'-->
        <gml:Point gml:id="skjer.47317_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.111007 10.927840</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.47319">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>fa5373bc-e6e8-4b1b-bb49-6ab246cb2246</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2016-05-03T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:58</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.47319_APP_POSISJON'-->
        <gml:Point gml:id="skjer.47319_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.122006 10.854768</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.47320">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>477a00ad-6f63-464a-aac3-53ef640c1fc2</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2016-05-03T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:58</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.47320_APP_POSISJON'-->
        <gml:Point gml:id="skjer.47320_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.111137 10.928175</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
  <wfs:member>
    <app:Skjær xmlns:app="http://skjema.geonorge.no/SOSI/produktspesifikasjon/Dybdedata/20201001" gml:id="skjer.47424">
      <app:identifikasjon>
        <app:Identifikasjon>
          <app:lokalId>7e8d8bf2-9822-426d-b8d3-183b7ff29852</app:lokalId>
          <app:navnerom>https://data.geonorge.no/sosi/dybdedata/sjokart_dybdedata</app:navnerom>
          <app:versjonId>20201001</app:versjonId>
        </app:Identifikasjon>
      </app:identifikasjon>
      <app:oppdateringsdato>2016-05-03T22:00:00</app:oppdateringsdato>
      <app:datauttaksdato>2026-08-24T12:09:58</app:datauttaksdato>
      <app:posisjon>
        <!--Inlined geometry 'skjer.47424_APP_POSISJON'-->
        <gml:Point gml:id="skjer.47424_APP_POSISJON" srsName="urn:ogc:def:crs:EPSG::4258">
          <gml:pos>59.110796 10.927299</gml:pos>
        </gml:Point>
      </app:posisjon>
    </app:Skjær>
  </wfs:member>
</wfs:FeatureCollection>